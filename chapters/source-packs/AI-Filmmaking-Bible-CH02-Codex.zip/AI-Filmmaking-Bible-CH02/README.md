# AI 電影製作聖經｜CH02 Codex 完整素材包

章名：鏡頭景別、構圖與攝影機語言。版本：1.0.0。日期：2026-10-18。

## 檔案

- `chapter/CH02-camera-language.md`：完整章節原稿（主檔）
- `glossary/CH02-glossary.json`：26 組核心術語
- `shot-lists/CH02-science-shortfilm.json`：60 秒、7 鏡頭案例資料
- `prompts/`：6 組生成及審片提示詞
- `exercises/CH02-assessment.md`：實作和評分
- `references/CH02-references.md`：來源、日期與待辦
- `CODEX-INSTRUCTIONS.md`：Codex 整合／驗證指令
- `assets/`：預留原創插圖與教學圖解（目前沒有假造素材）

## 匯入

將本包解壓至主專案的章節 staging 區，要求 Codex 讀取 `CODEX-INSTRUCTIONS.md`。請優先保留 Markdown 主檔和可編輯 JSON。

## 編輯狀態

完整教學初稿已具備；電影攝影理論仍需版本頁碼查核，專業圖解和真實生成實測尚待製作。
