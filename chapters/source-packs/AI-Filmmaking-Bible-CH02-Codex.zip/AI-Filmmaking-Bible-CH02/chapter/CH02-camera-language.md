---
title: "第二章｜鏡頭景別、構圖與攝影機語言"
book: "AI 電影製作聖經"
part: "第一篇｜電影語言與影視美學"
chapter: 2
version: "1.0.0"
locale: "zh-TW"
updated: "2026-10-18"
status: "draft-for-editorial-review"
keywords: [景別, 構圖, 焦距, 透視, 景深, 運鏡, AI影片, 分鏡]
---

# 第二章｜鏡頭景別、構圖與攝影機語言

副標題：從導演意圖到 AI 可操作、可驗證的鏡頭規格

> 核心命題：鏡頭不是「拍得好看」的選擇，而是決定觀眾距離人物有多近、知道多少資訊、看向哪裡，以及在多長時間內建立何種感受的敘事行為。

**讀者定位**：已有基本剪輯概念、希望系統化掌握電影攝影與 AI 動畫製片的創作者、教師及技術人員。

**本章使用方式**：先學術語與原理，再做「同一場景不同景別」實驗；最後把導演意圖轉換為 Shot Spec、Prompt、生成素材和品質評估。文中的 AI 控制語句是目標描述，不保證模型按照物理攝影機精確執行。

## 學習成果

完成本章，應能：
1. 選擇並解釋 EWS、WS、FS、MS、MCU、CU、ECU 等景別。
2. 區分景別、構圖、攝影機角度、焦距、攝影機距離與景深。
3. 解釋透視的主要決定因素，以及 Dolly 與 Zoom 的差異。
4. 比較 Pan、Tilt、Truck、Dolly、Pedestal、Crane、Orbit、Handheld 與 Locked-off。
5. 使用視線、180 度軸線、Headroom、Lead Room 和 連續性原則設計跨鏡頭空間。
6. 為鏡頭建立可傳入 Codex 的 JSON 規格與驗收標準。
7. 製作 30–60 秒示範短片並提交反思與評量。

## 2.1 鏡頭語言的六個獨立維度

設計一個鏡頭時，至少拆成：①景別（Shot size：主體在畫面中佔多大）；②構圖（Composition：元素在畫面何處）；③角度（Angle：從何種視點觀看）；④鏡頭／光學表現（Lens look：視角、景深、畸變與散景）；⑤運動（Movement：攝影機與主體如何變化）；⑥時間（Duration & temporal progression：從起點到終點的過程）。另外要註記敘事目的、場面調度、聲音、連續性與評估準則。

反例：「電影感、35mm、特寫、鏡頭快速拉遠」可能互相牴觸：若同時要求主體始終保持相同大小，又要求鏡頭迅速後退，必須有明確變焦或角色移動補償。導演應先選擇最重要的效果，而不是堆疊形容詞。

### 2.1.1 操作順序

先問：希望觀眾注意什麼？再問：人物和場景的關係為何？再決定景別、角度、運鏡和光學效果。最後才決定工具生成參數。**觀眾意圖→可見行為→鏡頭規格→生成指令→審片證據**，應是整章一以貫之的轉換鏈。

## 2.2 景別大全（Shot Size）

景別依主體在畫面中的相對尺度命名，不是焦距大小。各劇組對邊界略有不同，以下以人物為主要參考。

| 英文 | 中文慣用稱呼 | 典型人物取景 | 主要敘事任務 | AI 模型提示寫法 |
|---|---|---|---|---|
| Extreme Wide Shot (EWS/ELS) | 極遠景／大遠景 | 人物極小，環境主導 | 建立尺度、距離、處境 | subject appears small in vast environment |
| Wide Shot (WS/LS) | 遠景／全景（依語境） | 人物全身與大量環境 | 交代空間及動作路線 | full body visible, surrounding classroom |
| Full Shot (FS) | 全身景 | 人物頭到腳可見 | 姿態、服裝、肢體動作 | head-to-toe framing |
| Medium Long Shot (MLS) | 中遠景／膝上景 | 通常膝部以上 | 人物動作與部分環境 | knees-up framing |
| Medium Shot (MS) | 中景 | 大致腰部以上 | 人物互動、對白與手勢 | waist-up framing |
| Medium Close-Up (MCU) | 中近景 | 胸部或肩胸以上 | 表情、語氣、親近感 | chest-up framing |
| Close-Up (CU) | 近景／特寫 | 頭臉或重要物件 | 表情、關鍵資訊 | face fills frame, eyes prominent |
| Extreme Close-Up (ECU) | 大特寫 | 眼睛、手指、細小細節 | 極度聚焦、揭示線索 | extreme close-up of fingertip |

**教學提醒**：同樣是 CU，可能是對人臉，也可能是對桌上的玻璃杯；不要把人像取景定義誤用到所有物件。畫面必須容納字幕及後製裁切空間時，也要提前保留安全區域。

### 2.2.1 景別的選擇不是「越近越有感」

遠景可讓觀眾觀察角色與空間的關係，也可能塑造自由或壓迫。特寫可以表現情感，但亦可能傳遞資訊、引發不安或刻意隱去環境。意義取決於前後鏡頭、表演、聲音及文化脈絡。

**練習 A｜同一行動三種景別**：教師拿起透明玻璃杯。EWS 告訴觀眾人身在何處；MS 顯示教師如何操作；CU 顯示杯壁的光影。試著交換順序並記錄觀眾的理解差異。

## 2.3 構圖（Composition）與視覺重心

### 2.3.1 三分法與中心構圖

三分法（Rule of Thirds）以兩條水平和兩條垂直等分線輔助定位主體；它是一種設計方法，不是不可違反的定律。中心構圖能讓主體直接、對稱、儀式感強；偏離中心則可能保留觀看方向的空間，或暗示失衡。任何構圖都應服務故事。

### 2.3.2 Headroom、Lead Room、Negative Space

**Headroom（頭頂留白）**：人物頭頂與畫框上方的空間，過多可營造壓縮或渺小，也可能只是錯誤留白。**Lead Room / Look Room（前方留白／視線留白）**：人物移動或注視方向留下的空間。**Negative Space（負空間）**：主體之外的區域，能形成視覺平衡、孤寂、等待或揭示空間。AI 生成時應描述主體位置、目光方向及畫面空白處的用途。

### 2.3.3 前景、中景、背景與視覺層次

將前景實驗器材、主體老師、背景學生安排在不同深度，可以同時透露故事資訊。但景深不足可能讓背景線索完全不可辨，景深過深也可能分散注意力。需依敘事取捨。

### 2.3.4 Leading Lines、Symmetry、Frame within Frame

引導線將視線引至主體；對稱可以建立秩序或不安；框中框可以強調觀察、隔閡或空間層次。例如教室窗框圍住玻璃杯，既構成畫中畫，也呼應光線探索主題。不要機械套用構圖法則：一個畫面可能同時運用多種方法。

### 2.3.5 畫面比例與裁切

16:9 適合一般橫式影片，9:16 適合直式短影音，1:1 和其他比例亦有特定展示情境。多平台交付時，關鍵人物、文字和道具不要壓在可能被裁掉的邊界。不同平台的 UI 安全區可能隨產品變化，正式輸出須另外查核。

## 2.4 攝影角度與敘事視點

| 術語 | 定義 | 可用效果 | 注意事項 |
|---|---|---|---|
| Eye Level | 與主體視線相近 | 平視、自然觀察 | 不表示必然中立 |
| High Angle | 向下俯視主體 | 顯示位置、脆弱或空間全貌 | 不等於鳥瞰 |
| Low Angle | 從低處向上拍 | 建立高度、力量或壓迫 | 誇張透視受距離影響 |
| Bird's-eye / Overhead | 高處接近垂直向下 | 展示配置、幾何或活動路徑 | 對物體相對位置須嚴格驗收 |
| Dutch Angle | 傾斜水平線 | 不穩定、失衡、風格化 | 過度使用易失去效果 |
| POV Shot | 從角色視角觀看 | 使觀眾共享視覺資訊 | 需要前後鏡頭建立主觀關係 |
| Over-the-Shoulder | 越肩鏡頭 | 建立對話及關係 | 必須檢查肩膀、視線、軸線 |

**重要區分**：角度不等於景別。一個低角度鏡頭仍可同時是 WS 或 CU。

## 2.5 光學語言：焦距、視角、距離、透視、景深

### 2.5.1 焦距不是景別

焦距以毫米描述鏡頭的光學參數，與感光元件尺寸共同影響視角；景別則是畫面中主體所佔的尺度。攝影機移動到不同距離，即使焦距不變，景別也會改變；不同焦距配合不同距離，也能得到相似的主體大小。

討論「24mm、35mm、50mm、85mm」的視覺特性時，務必聲明感光元件格式或標示「全片幅等效」。否則單報焦距常缺乏可比較意義。

### 2.5.2 透視主要由攝影機位置決定

常聽到「長焦壓縮透視」，更精確的說法是：為保持相同主體大小而使用長焦鏡頭時，攝影機通常會後退；**攝影機與場景的相對距離**造成前後景相對大小關係的改變。單純從同一位置變更焦距，然後裁切到相同畫面範圍，不會改變物體的透視幾何。

### 2.5.3 景深（Depth of Field）

景深是觀眾可感到清晰的距離範圍，受到光圈、焦距、對焦距離、感光元件及觀看條件等因素共同影響。**Shallow Depth of Field（淺景深）**可把主體從背景分離；**Deep Focus（深焦）**讓近處與遠處資訊同時可辨。AI 模型輸入「f/1.8」未必真的依鏡頭光學計算，應以「sharp face and softly blurred background」等可見結果描述並驗證。

### 2.5.4 Dolly 與 Zoom 的核心差異

**Dolly-in**：攝影機實際向主體前進，前後景相對位置和視差可能隨運動改變。**Zoom-in**：攝影機位置不變，改變焦距而放大畫面；理想情況下不會創造由攝影機平移帶來的視差。**Dolly Zoom**：同時移動攝影機與反向變焦，使主體尺度大致維持，背景透視關係發生明顯變化。在 AI 生成中，若只輸入「dolly zoom」，經常要另外驗證主體尺度、背景變化與形變。

## 2.6 運鏡（Camera Movement）完整入門

| 運鏡 | 攝影機如何動 | 與容易混淆的概念比較 | 示例用途 |
|---|---|---|---|
| Locked-off / Static | 攝影機固定 | 主體仍可移動 | 讓觀眾觀察細微動作 |
| Pan | 攝影機水平轉動 | 不是整台橫移 | 跟隨學生從左走到右 |
| Tilt | 攝影機垂直轉動 | 不是上下升降 | 從桌面望向老師表情 |
| Dolly In / Out | 整台攝影機前後移動 | 與 Zoom 不同 | 逐步聚焦物件 |
| Truck / Track Lateral | 攝影機橫向平移 | 與 Pan 不同 | 平行跟拍走廊人物 |
| Pedestal | 攝影機上下平移 | 與 Tilt 不同 | 從低位置升到視線高度 |
| Crane / Jib | 攝影機沿弧線或高低路徑移動 | 可結合多軸移動 | 展示教室全貌 |
| Orbit / Arc | 攝影機繞主體移動 | 與主體自轉不同 | 展示器材的空間結構 |
| Handheld | 手持的細小不穩定運動 | 不等於故意亂抖 | 臨場感、主觀緊張 |
| Tracking | 攝影機追蹤移動主體 | 可用軌道、穩定器等完成 | 跟著老師走入教室 |
| Rack Focus | 焦點在不同距離間轉換 | 不是攝影機移動 | 從玻璃杯轉焦到學生 |
| Whip Pan | 很快速的水平搖攝 | 會產生明顯動態模糊 | 快節奏轉場 |

運鏡至少要說清楚四件事：起點、運動方向、速度曲線、終點。例如「從老師半身中景緩慢推進至手中種子近景，5 秒內連續完成，背景自然產生視差」。若工具只能提供 5 秒固定長度，先調整鏡頭設計並在剪輯中試驗，不要假設提示詞可保證每秒的精確位置。

### 2.6.1 動作與運鏡應分開描述

「鏡頭推進」是 camera motion；「老師轉身」是 subject motion；「樹葉隨風搖動」是 environment motion。混在一起容易增加生成錯誤，建議先成功控制主要動作，再逐項增加副動作。

### 2.6.2 不是每個鏡頭都要動

固定鏡頭能呈現觀察、等待、幾何構圖和真實時間。部分生成模型可能預設產生不必要的飄移，應明確描述 locked-off camera、minimal subject motion，生成後必要時使用編輯器穩定影像。

## 2.7 空間連續性與 180 度規則

人物 A、B 對話時，先建立兩者關係的想像軸線。同一場對話若在同側拍攝，通常較容易維持左右與視線方向的理解。跨越軸線並非禁止，但應以中性鏡頭、人物走位、鏡頭運動或敘事動機重新建立空間關係。

### 2.7.1 對 AI 影片的特別要求

每一鏡記錄：角色站位（screen-left/right）、看向何處（eyeline）、道具與門窗位置、光線方向、是否跨軸。若角色參考影像與場景參考圖不一致，優先修正參考輸入，不要只堆疊文字否定描述。

### 2.7.2 專業審片問題

觀眾能否說出誰在左誰在右？人物的目光是否能合理接到所看事物？主體走出右側後，下一鏡是否有可理解的入畫方向？鏡頭反轉是否是創作選擇而非生成失誤？

## 2.8 AI 導演的鏡頭提示詞方法

本書採用分層格式，避免單一句「cinematic masterpiece」取代具體導演工作：

1. **Intent（目的）**：希望觀眾理解或感受什麼。
2. **Composition（取景）**：景別、主體位置、背景線索。
3. **Camera（視點）**：角度、距離感、運鏡與速度。
4. **Action（動作）**：主體、場景、攝影機分離描述。
5. **Continuity（連續性）**：人物、道具、空間、燈光參考。
6. **Deliverable（交付）**：預期時長、比例、輸出規格。
7. **Acceptance（驗收）**：可觀察、可比較的結果。

**Text-to-Video**：提示詞需要包含主體、場景、構圖與動作等資訊。

**Image-to-Video**：若已提供高品質參考圖，提示詞通常更應聚焦「哪些物件動、鏡頭怎麼動、按什麼順序動」。Runway 官方文件也主張依工作模式分配描述重點，從簡單提示逐次增加約束。[R01][R02][R03]

**不可假設精準控制**：對於焦距、焦點、攝影機實際路徑與物理相機參數，應列為「欲呈現的視覺表現」，不是模型已提供物理模擬的證明。生成時長、畫面比例、參考圖數量與攝影控制選項，需以當前使用工具的官方文件為準。

### 2.8.1 可複製提示詞示例

**P01｜Text-to-Video｜EWS 建立場景**

> Extreme wide establishing shot of a quiet elementary science classroom at dawn. The teacher appears small in the background. Morning light streams through the left windows. Locked-off camera, subtle dust particles moving in the light, restrained natural motion, calm atmosphere, continuous shot.

**P02｜Image-to-Video｜MS 跟拍**

> The camera tracks slowly alongside the teacher from left to right as the teacher walks toward the experiment table. Stable medium framing, natural footsteps, smooth motion, one continuous take. The background shifts with consistent parallax.

**P03｜Image-to-Video｜CU 緩慢推進**

> The camera makes a very slow dolly-in toward the transparent glass on the desk. The glass remains stationary. Sunlight patterns remain coherent as the perspective changes subtly. Single continuous shot, gentle movement, no abrupt reframing.

**P04｜Image-to-Video｜固定鏡頭**

> Locked-off camera remains stationary. The teacher's hand slowly reaches into frame and picks up the notebook. Only the hand and notebook move; the surrounding classroom remains still. Continuous natural action.

**P05｜反應鏡頭**

> Medium close-up, eye-level framing. The teacher looks at the refracted light, then raises the eyebrows slightly in quiet curiosity. Stationary camera, subtle believable facial motion, consistent morning window light.

**P06｜視覺連續性核對指令（給多模態審片模型或人工檢查）**

> Compare the reference frame and candidate shot. Report differences in character identity, clothing, glass shape, prop position, window direction, eyeline, lighting direction and camera framing. Separate observed mismatches from uncertain observations. Do not claim physical accuracy from appearance alone.

## 2.9 完整案例：《光從哪裡來？》60 秒科普短片

**Logline**：學生發現玻璃杯後方的字看起來改變，老師以一個問題，引導孩子思考光線行進與折射現象。

**科學界線**：影像只能作為動機與觀察示意，不能將生成光學效果當作實驗證據。若要說明折射原因，應補充實拍、圖解、條件控制與可再現的科學演示。

| Shot | 時間碼 | 景別／角度 | 動作與運鏡 | 敘事功能 | 音訊 |
|---|---|---|---|---|---|
| S01 | 00:00–00:07 | EWS 平視 | 教室晨光、固定 | 建立時間地點 | 環境聲 |
| S02 | 00:07–00:16 | MS 平視 | 學生拿杯子，緩慢橫移 | 人物與事件 | 桌面聲 |
| S03 | 00:16–00:24 | CU 平視 | 文字透過杯水變化，固定 | 聚焦觀察 | 音樂提示 |
| S04 | 00:24–00:31 | MCU 平視 | 學生疑惑，固定 | 反應 | 「為什麼不同？」 |
| S05 | 00:31–00:42 | OTS 略俯角 | 老師示範，微推進 | 引導問題 | 教師旁白 |
| S06 | 00:42–00:53 | Insert／俯拍 | 手畫出觀察與假設 | 觀察轉思考 | 筆觸音效 |
| S07 | 00:53–01:00 | WS 平視 | 拉遠到討論情境 | 收束與提問 | 音樂結尾 |

### 2.9.1 S03 鏡頭案例的技術細化

- 鏡頭目的：在不揭露答案前吸引觀眾觀察。
- 起始構圖：透明杯與杯後字卡同時可見，讓觀眾理解空間關係。
- 視角：接近桌面高度，固定攝影機優先，避免誇張運鏡掩蓋觀察線索。
- 光學：要求文字與杯身清晰，但不用無法驗證的「真實物理折射」當作模型保證。
- 連續性：字卡位置、杯子形狀、水位、光線方向維持一致。
- 科學驗收：與實際裝置對照；若效果不符，標示為示意或改用實拍。

## 2.10 品質檢查與故障排除

| 觀察到的問題 | 可能原因 | 改善次序 |
|---|---|---|
| 角色的臉或衣服變了 | 缺少固定參考；場景描述重複生成 | 固定角色參考→減少變動描述→重新生成 |
| 鏡頭說 Dolly 實際只是放大 | 模型用數位裁切代替透視移動 | 檢查前後景視差→指定相機實際平移→必要時改用 3D／實拍 |
| 固定鏡頭還在飄 | 模型偏好動態 | 明確 locked-off→縮小主體動作→後製穩定 |
| 人物左右位置翻轉 | 缺場景配置與軸線資訊 | 建立 blocking map→固定 screen direction→跨鏡比對 |
| 特寫失去情境 | 缺少建立鏡頭 | 前置 WS／OTS 或補一個 contextual insert |
| 景深很淺卻看不清線索 | 敘事焦點與光學風格衝突 | 改焦點位置→加深景深→分兩鏡頭 |
| 物理效果不正確 | 模型模擬不具實驗可靠性 | 實拍或以標記圖解示意，註明限制 |
| 9:16 裁切切掉手和器材 | 未設安全構圖 | 拆版本、重新構圖，勿僅機械裁切 |

### 2.10.1 建議紀錄的生成資料

模型與版號、提示詞文字、參考圖 URI/檔案雜湊、設定參數、候選 Take ID、審片人、品質評分、已知問題與最終素材檔。對不支援的參數留 `null`，不可虛構。

## 2.11 實作任務與評量

### 任務 A｜相同主題的景別比較

拍攝或生成「手拿起一顆種子」，各做 EWS、MS、CU 三個版本。寫下每段畫面讓觀眾注意到的資訊，並對照是否達成目標。

### 任務 B｜Dolly vs Zoom

使用場景中前、中、後景可辨識的擺設，分別製作 Dolly-in 與 Zoom-in。逐格觀察前後景相對位移；若 AI 不符合預期，留下失敗版本，描述如何修改。

### 任務 C｜30–60 秒敘事短片

用 5–8 個鏡頭說出「一個發現」。至少包含 WS、MS、CU、兩種角度、一段固定攝影機鏡頭，以及一個有明確理由的運鏡。繳交 Shot List、2 組 Prompt 版本與最後成品，另交一頁反思。

### 評量量規（總分 100）

| 面向 | 配分 | 達標描述 |
|---|---:|---|
| 景別與構圖的敘事目的 | 25 | 選擇能清楚解釋且確有作用 |
| 攝影角度／運鏡正確性 | 20 | 能區分各運動並合理使用 |
| 時空與動作連續性 | 20 | 人物位置、軸線、道具與動作可理解 |
| AI 規格與版本紀錄 | 20 | 規格、提示詞、參考、候選和修正可追溯 |
| 品質驗證與反思 | 15 | 能指出偏差、修復依據與模型限制 |

建議成績等級：90–100 優秀；80–89 良好；70–79 基礎達標；60–69 待加強；低於 60 應重新修訂。級距為本書教學建議而非官方標準。

### 思考題

1. 攝影機位置不動，把 35mm 改為 85mm，透視一定改變嗎？為何？
2. 什麼時候選擇固定鏡頭，比持續運鏡更有效？
3. 為什麼同一段 AI 影片中「臉清楚」不代表跨鏡頭人物一致？
4. 若為 9:16 重剪 16:9 科普影片，哪幾種鏡頭應優先重構圖？
5. 當生成畫面漂亮但折射不符合真實實驗，該如何處理？

**簡答提示**：第 1 題，固定攝影機位置時透視幾何不因單純改焦距而改變；觀看畫角與裁切範圍會改變。第 5 題，避免把 AI 圖像當證據；可改用實拍與驗證過的科學圖解，或清楚標示為示意。

## 2.12 章末摘要

- 景別決定主體相對尺度；角度決定觀看方向；構圖決定畫面元素關係。
- 焦距、相機距離、感光元件與景深不能混為一談。
- Dolly、Pan、Truck、Zoom 各代表不同的運動或光學操作。
- AI 提示詞應描述可看見、可檢查的運動結果，不能把術語視為精準執行的保證。
- 敘事意圖與跨鏡頭連續性，比單一鏡頭的華麗特效更重要。

**本章最重要的一句話**：先決定讓觀眾看見什麼，再決定攝影機怎麼看；最後才決定讓 AI 如何生成。

## 參考文獻、查證與出版註記

官方線上來源（已於 2026-10-18 查閱；產品功能可變動）：

- [R01] Runway Academy, *Prompting Guide*. https://academy.runwayml.com/guides/prompting-guide
- [R02] Runway, *Gen-4 Video Prompting Guide*. https://help.runwayml.com/hc/en-us/articles/39789879462419-Gen-4-Video-Prompting-Guide
- [R03] Runway, *Image to Video Prompting Guide*. https://help.runwayml.com/hc/en-us/articles/48324313115155-Image-to-Video-Prompting-Guide
- [R04] Runway, *AI Camera Prompts* (2026-08-21). https://runway.com/resources/ai-camera-prompts
- [R05] Runway, *AI Camera Control* (2026-10-12). https://runway.com/resources/ai-camera-control

延伸基礎書目（請出版編輯依實際採用版本確認版次、頁碼與引用）：

- Bordwell, Thompson & Smith, *Film Art: An Introduction*.
- Bruce Block, *The Visual Story*.
- Joseph V. Mascelli, *The Five C's of Cinematography*.

**編輯備註**：本章的案例及提示詞是教學設計，未宣稱實際生成成功。尚需製作授權合規的鏡頭圖解、同場景對照圖、Runway 等工具的實測結果、傳統攝影術語頁碼引用與科學演示比對。示意資料不可冒充攝影實測證據。
