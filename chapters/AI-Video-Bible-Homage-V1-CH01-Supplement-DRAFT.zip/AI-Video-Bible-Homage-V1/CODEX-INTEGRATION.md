# Codex 安全整合任務

先閱讀本包及專案 planning-v2/CH01-V2-WORKPLAN.md、BUILD-VALIDATION-V2.md；比對 metadata/chapters.yaml、canonical CH01 雙語稿及 legacy CH01。先產生差異報告與備份，不要覆蓋現有原稿。

將 CH01 兩份 HOMAGE INSERT 按段落 ID 合併入相應章節；保留原章節語意和編輯審核狀態；五張致敬圖採獨立 namespace `CH01-HOMAGE-FIG-*` 避免舊 figure ID 衝突。將電影索引作為「候選清單」匯入 metadata，核對 CH01-CH60 真正章節題目後才分派引用。

依 BRIEFS 製作原創示意圖，絕不可下載原片劇照或讓 AI 精確重畫原劇照；待人工 rights/technical/editorial 核准後才記錄 approved；修正雙語 caption/alt。完成網站、PDF、EPUB、DOCX 實測，執行嚴格中文字型 gate、產出 SHA256 與驗收報告。發行前一定由作者核准，禁止部署與 push。
