# 經典致敬電影索引｜卷末附錄候選 V1.0

本清單為編輯草稿。演員採代表性演員而非完整卡司；劇情為自行撰寫的極簡介紹。除明列官方來源的獎項外，全部標示待查，避免把提名誤寫成得獎。

## FILM-001 《公民凱恩》 / *Citizen Kane* (1941)
- 導演：Orson Welles
- 代表演員：Orson Welles; Joseph Cotten
- 劇情簡介：新聞巨擘一生的碎片式回溯
- 本書分析重點：Deep focus, low angles, non-linear narration
- 章節候選：CH01 CH02 CH09 CH14
- 獎項：1942 奧斯卡最佳原創劇本（獎項細節仍須官方複核）。

## FILM-002 《羅生門》 / *Rashomon* (1950)
- 導演：Akira Kurosawa
- 代表演員：Toshiro Mifune; Machiko Kyo
- 劇情簡介：同一事件的互相矛盾證詞
- 本書分析重點：Multiple perspectives and unreliable narration
- 章節候選：CH01 CH11 CH26
- 獎項：待官方來源核實，不編造獎項。

## FILM-003 《悲情城市》 / *A City of Sadness* (1989)
- 導演：Hou Hsiao-hsien
- 代表演員：Tony Leung Chiu-wai; Chen Sung-young
- 劇情簡介：家庭命運與歷史轉折
- 本書分析重點：Long takes, offscreen space, historical context
- 章節候選：CH01 CH06 CH27
- 獎項：待官方來源核實，不編造獎項。

## FILM-004 《一一》 / *Yi Yi* (2000)
- 導演：Edward Yang
- 代表演員：Wu Nien-jen; Elaine Jin
- 劇情簡介：臺北家庭成員的人生交織
- 本書分析重點：Urban compositions and layered perspectives
- 章節候選：CH01 CH02 CH20
- 獎項：待官方來源核實，不編造獎項。

## FILM-005 《花樣年華》 / *In the Mood for Love* (2000)
- 導演：Wong Kar-wai
- 代表演員：Tony Leung Chiu-wai; Maggie Cheung
- 劇情簡介：鄰居在情感壓抑中相互靠近
- 本書分析重點：Framing, repetition, color, music
- 章節候選：CH01 CH02 CH15 CH22
- 獎項：2000 坎城影展最佳男演員（梁朝偉）、技術大獎。 https://www.festival-cannes.com/en/retrospective/2000/awards/

## FILM-006 《2001太空漫遊》 / *2001: A Space Odyssey* (1968)
- 導演：Stanley Kubrick
- 代表演員：Keir Dullea; Gary Lockwood
- 劇情簡介：人類與智慧及宇宙的探索
- 本書分析重點：Symmetry, pacing, sound-image relations
- 章節候選：CH02 CH08 CH24
- 獎項：待官方來源核實，不編造獎項。

## FILM-007 《教父》 / *The Godfather* (1972)
- 導演：Francis Ford Coppola
- 代表演員：Marlon Brando; Al Pacino
- 劇情簡介：黑幫家族的權力傳承
- 本書分析重點：Low-key lighting, power blocking
- 章節候選：CH02 CH17 CH29
- 獎項：待官方來源核實，不編造獎項。

## FILM-008 《大白鯊》 / *Jaws* (1975)
- 導演：Steven Spielberg
- 代表演員：Roy Scheider; Robert Shaw
- 劇情簡介：海邊小鎮遭到鯊魚威脅
- 本書分析重點：Offscreen threat, suspense, musical motif
- 章節候選：CH05 CH19 CH34
- 獎項：待官方來源核實，不編造獎項。

## FILM-009 《搶救雷恩大兵》 / *Saving Private Ryan* (1998)
- 導演：Steven Spielberg
- 代表演員：Tom Hanks; Matt Damon
- 劇情簡介：戰時小隊奉命尋找士兵
- 本書分析重點：Handheld immediacy, desaturation, sound
- 章節候選：CH02 CH04 CH36
- 獎項：待官方來源核實，不編造獎項。

## FILM-010 《臥虎藏龍》 / *Crouching Tiger, Hidden Dragon* (2000)
- 導演：Ang Lee
- 代表演員：Chow Yun-fat; Michelle Yeoh
- 劇情簡介：武俠人物的情感與責任
- 本書分析重點：Action choreography and landscape
- 章節候選：CH03 CH21 CH32
- 獎項：待官方來源核實，不編造獎項。

## FILM-011 《俠女》 / *A Touch of Zen* (1971)
- 導演：King Hu
- 代表演員：Hsu Feng; Shih Chun
- 劇情簡介：書生捲入江湖權力鬥爭
- 本書分析重點：Action staging, editing and architecture
- 章節候選：CH03 CH18 CH32
- 獎項：待官方來源核實，不編造獎項。

## FILM-012 《霸王別姬》 / *Farewell My Concubine* (1993)
- 導演：Chen Kaige
- 代表演員：Leslie Cheung; Gong Li
- 劇情簡介：戲曲演員與時代變遷
- 本書分析重點：Historical narrative, performance and costume
- 章節候選：CH04 CH21 CH37
- 獎項：待官方來源核實，不編造獎項。

## FILM-013 《刺客聶隱娘》 / *The Assassin* (2015)
- 導演：Hou Hsiao-hsien
- 代表演員：Shu Qi; Chang Chen
- 劇情簡介：女刺客在任務與情感間抉擇
- 本書分析重點：Negative space, lighting, restrained action
- 章節候選：CH03 CH06 CH38
- 獎項：待官方來源核實，不編造獎項。

## FILM-014 《異星入境》 / *Arrival* (2016)
- 導演：Denis Villeneuve
- 代表演員：Amy Adams; Jeremy Renner
- 劇情簡介：語言學家嘗試理解外星訪客
- 本書分析重點：Nonlinear revelation and sound design
- 章節候選：CH07 CH11 CH40
- 獎項：待官方來源核實，不編造獎項。

## FILM-015 《銀翼殺手》 / *Blade Runner* (1982)
- 導演：Ridley Scott
- 代表演員：Harrison Ford; Rutger Hauer
- 劇情簡介：未來城市的仿生人追緝
- 本書分析重點：Atmospheric production design, lighting
- 章節候選：CH03 CH17 CH42
- 獎項：待官方來源核實，不編造獎項。

## FILM-016 《銀翼殺手2049》 / *Blade Runner 2049* (2017)
- 導演：Denis Villeneuve
- 代表演員：Ryan Gosling; Harrison Ford
- 劇情簡介：複製人警探追索自身來源
- 本書分析重點：Color architecture and visual scale
- 章節候選：CH03 CH17 CH43
- 獎項：待官方來源核實，不編造獎項。

## FILM-017 《星際效應》 / *Interstellar* (2014)
- 導演：Christopher Nolan
- 代表演員：Matthew McConaughey; Anne Hathaway
- 劇情簡介：太空探索與親子情感
- 本書分析重點：Sound, time structure, visual effects
- 章節候選：CH05 CH08 CH45
- 獎項：待官方來源核實，不編造獎項。

## FILM-018 《記憶拼圖》 / *Memento* (2000)
- 導演：Christopher Nolan
- 代表演員：Guy Pearce; Carrie-Anne Moss
- 劇情簡介：失去短期記憶者追尋真相
- 本書分析重點：Reverse chronology, subjective narration
- 章節候選：CH04 CH11 CH46
- 獎項：待官方來源核實，不編造獎項。

## FILM-019 《瘋狂麥斯：憤怒道》 / *Mad Max: Fury Road* (2015)
- 導演：George Miller
- 代表演員：Tom Hardy; Charlize Theron
- 劇情簡介：末日追逐與反抗
- 本書分析重點：Action readability and centered framing
- 章節候選：CH04 CH12 CH47
- 獎項：待官方來源核實，不編造獎項。

## FILM-020 《寄生上流》 / *Parasite* (2019)
- 導演：Bong Joon-ho
- 代表演員：Song Kang-ho; Choi Woo-shik
- 劇情簡介：階級不同的兩個家庭相遇
- 本書分析重點：Spatial hierarchy and staging
- 章節候選：CH07 CH20 CH48
- 獎項：2020 奧斯卡最佳影片、最佳導演、最佳國際影片等。 https://www.oscars.org/oscars/ceremonies/2020

## FILM-021 《媽的多重宇宙》 / *Everything Everywhere All at Once* (2022)
- 導演：Daniel Kwan; Daniel Scheinert
- 代表演員：Michelle Yeoh; Stephanie Hsu
- 劇情簡介：家庭困境交織多重宇宙
- 本書分析重點：Multiverse editing and practical ingenuity
- 章節候選：CH04 CH13 CH49
- 獎項：待官方來源核實，不編造獎項。

## FILM-022 《七武士》 / *Seven Samurai* (1954)
- 導演：Akira Kurosawa
- 代表演員：Toshiro Mifune; Takashi Shimura
- 劇情簡介：武士協助農村抵抗盜賊
- 本書分析重點：Ensemble blocking and action geography
- 章節候選：CH02 CH10 CH50
- 獎項：待官方來源核實，不編造獎項。

## FILM-023 《東京物語》 / *Tokyo Story* (1953)
- 導演：Yasujiro Ozu
- 代表演員：Chishu Ryu; Setsuko Hara
- 劇情簡介：年長父母探望成年子女
- 本書分析重點：Low camera height and contemplative cuts
- 章節候選：CH06 CH23 CH51
- 獎項：待官方來源核實，不編造獎項。

## FILM-024 《牯嶺街少年殺人事件》 / *A Brighter Summer Day* (1991)
- 導演：Edward Yang
- 代表演員：Chang Chen; Lisa Yang
- 劇情簡介：少年在社會變動中迷失
- 本書分析重點：Long-form ensemble staging
- 章節候選：CH05 CH26 CH52
- 獎項：待官方來源核實，不編造獎項。

## FILM-025 《海角七號》 / *Cape No. 7* (2008)
- 導演：Wei Te-sheng
- 代表演員：Van Fan; Tanaka Chie
- 劇情簡介：地方樂團與跨時代書信
- 本書分析重點：Ensemble music and local storytelling
- 章節候選：CH05 CH27 CH53
- 獎項：待官方來源核實，不編造獎項。

## FILM-026 《歡迎來到布達佩斯大飯店》 / *The Grand Budapest Hotel* (2014)
- 導演：Wes Anderson
- 代表演員：Ralph Fiennes; Tony Revolori
- 劇情簡介：飯店禮賓員與門生的冒險
- 本書分析重點：Symmetry, aspect ratio and art direction
- 章節候選：CH02 CH17 CH54
- 獎項：待官方來源核實，不編造獎項。

## FILM-027 《樂來越愛你》 / *La La Land* (2016)
- 導演：Damien Chazelle
- 代表演員：Ryan Gosling; Emma Stone
- 劇情簡介：洛杉磯兩名藝術追夢者
- 本書分析重點：Long takes, musicals, color scripting
- 章節候選：CH03 CH05 CH55
- 獎項：待官方來源核實，不編造獎項。

## FILM-028 《駭客任務》 / *The Matrix* (1999)
- 導演：Lana Wachowski; Lilly Wachowski
- 代表演員：Keanu Reeves; Carrie-Anne Moss
- 劇情簡介：程式設計師發現現實不如所見
- 本書分析重點：Bullet time and action previs
- 章節候選：CH13 CH33 CH56
- 獎項：待官方來源核實，不編造獎項。

## FILM-029 《楚門的世界》 / *The Truman Show* (1998)
- 導演：Peter Weir
- 代表演員：Jim Carrey; Laura Linney
- 劇情簡介：男子發現人生是電視節目
- 本書分析重點：Surveillance framing and point of view
- 章節候選：CH02 CH25 CH57
- 獎項：待官方來源核實，不編造獎項。

## FILM-030 《摩登時代》 / *Modern Times* (1936)
- 導演：Charlie Chaplin
- 代表演員：Charlie Chaplin; Paulette Goddard
- 劇情簡介：工業化社會裡的工作與生存
- 本書分析重點：Visual comedy and rhythmic action
- 章節候選：CH04 CH23 CH58
- 獎項：待官方來源核實，不編造獎項。

## FILM-031 《神隱少女》 / *Spirited Away* (2001)
- 導演：Hayao Miyazaki
- 代表演員：Rumi Hiiragi (voice); Miyu Irino (voice)
- 劇情簡介：少女在神靈世界尋找歸途
- 本書分析重點：World building, color, sound and animation
- 章節候選：CH18 CH31 CH59
- 獎項：待官方來源核實，不編造獎項。

## FILM-032 《黑獄亡魂》 / *The Third Man* (1949)
- 導演：Carol Reed
- 代表演員：Joseph Cotten; Orson Welles
- 劇情簡介：戰後維也納的一樁謎案
- 本書分析重點：Dutch angles, shadow and suspense
- 章節候選：CH03 CH19 CH60
- 獎項：待官方來源核實，不編造獎項。
