# AI Video Bible｜全書經典電影致敬清單 V1.0

狀態：編輯候選清單，不是已完成的獎項資料庫。共 32 部國內外影片，覆蓋 CH01–CH60 的候選交叉引用。每部的年代、導演、演員、劇情、技法請在正式付印前按原始資料複核；獎項欄一律待影展／影藝學院官方逐條確認。

**60 章配置原則**：沿用專案 metadata/chapters.yaml 既有章名與 ID，絕不修改原始目錄；下表 CH 編號是候選對應，須由 Codex 讀取完整 60 章題綱確認吻合後才能寫入各章。第 60 章若已有其他教學內容，電影總索引採卷末附錄，不擅自替換 CH60。

| ID | 電影／英文原名 | 年份 | 導演 | 適合分析的技法 | 候選章節 |
|---|---|---|---|---|---|
| FILM-001 | 《公民凱恩》 *Citizen Kane* | 1941 | Orson Welles | Deep focus, low angles, non-linear narration | CH01 CH02 CH09 CH14 |
| FILM-002 | 《羅生門》 *Rashomon* | 1950 | Akira Kurosawa | Multiple perspectives and unreliable narration | CH01 CH11 CH26 |
| FILM-003 | 《悲情城市》 *A City of Sadness* | 1989 | Hou Hsiao-hsien | Long takes, offscreen space, historical context | CH01 CH06 CH27 |
| FILM-004 | 《一一》 *Yi Yi* | 2000 | Edward Yang | Urban compositions and layered perspectives | CH01 CH02 CH20 |
| FILM-005 | 《花樣年華》 *In the Mood for Love* | 2000 | Wong Kar-wai | Framing, repetition, color, music | CH01 CH02 CH15 CH22 |
| FILM-006 | 《2001太空漫遊》 *2001: A Space Odyssey* | 1968 | Stanley Kubrick | Symmetry, pacing, sound-image relations | CH02 CH08 CH24 |
| FILM-007 | 《教父》 *The Godfather* | 1972 | Francis Ford Coppola | Low-key lighting, power blocking | CH02 CH17 CH29 |
| FILM-008 | 《大白鯊》 *Jaws* | 1975 | Steven Spielberg | Offscreen threat, suspense, musical motif | CH05 CH19 CH34 |
| FILM-009 | 《搶救雷恩大兵》 *Saving Private Ryan* | 1998 | Steven Spielberg | Handheld immediacy, desaturation, sound | CH02 CH04 CH36 |
| FILM-010 | 《臥虎藏龍》 *Crouching Tiger, Hidden Dragon* | 2000 | Ang Lee | Action choreography and landscape | CH03 CH21 CH32 |
| FILM-011 | 《俠女》 *A Touch of Zen* | 1971 | King Hu | Action staging, editing and architecture | CH03 CH18 CH32 |
| FILM-012 | 《霸王別姬》 *Farewell My Concubine* | 1993 | Chen Kaige | Historical narrative, performance and costume | CH04 CH21 CH37 |
| FILM-013 | 《刺客聶隱娘》 *The Assassin* | 2015 | Hou Hsiao-hsien | Negative space, lighting, restrained action | CH03 CH06 CH38 |
| FILM-014 | 《異星入境》 *Arrival* | 2016 | Denis Villeneuve | Nonlinear revelation and sound design | CH07 CH11 CH40 |
| FILM-015 | 《銀翼殺手》 *Blade Runner* | 1982 | Ridley Scott | Atmospheric production design, lighting | CH03 CH17 CH42 |
| FILM-016 | 《銀翼殺手2049》 *Blade Runner 2049* | 2017 | Denis Villeneuve | Color architecture and visual scale | CH03 CH17 CH43 |
| FILM-017 | 《星際效應》 *Interstellar* | 2014 | Christopher Nolan | Sound, time structure, visual effects | CH05 CH08 CH45 |
| FILM-018 | 《記憶拼圖》 *Memento* | 2000 | Christopher Nolan | Reverse chronology, subjective narration | CH04 CH11 CH46 |
| FILM-019 | 《瘋狂麥斯：憤怒道》 *Mad Max: Fury Road* | 2015 | George Miller | Action readability and centered framing | CH04 CH12 CH47 |
| FILM-020 | 《寄生上流》 *Parasite* | 2019 | Bong Joon-ho | Spatial hierarchy and staging | CH07 CH20 CH48 |
| FILM-021 | 《媽的多重宇宙》 *Everything Everywhere All at Once* | 2022 | Daniel Kwan; Daniel Scheinert | Multiverse editing and practical ingenuity | CH04 CH13 CH49 |
| FILM-022 | 《七武士》 *Seven Samurai* | 1954 | Akira Kurosawa | Ensemble blocking and action geography | CH02 CH10 CH50 |
| FILM-023 | 《東京物語》 *Tokyo Story* | 1953 | Yasujiro Ozu | Low camera height and contemplative cuts | CH06 CH23 CH51 |
| FILM-024 | 《牯嶺街少年殺人事件》 *A Brighter Summer Day* | 1991 | Edward Yang | Long-form ensemble staging | CH05 CH26 CH52 |
| FILM-025 | 《海角七號》 *Cape No. 7* | 2008 | Wei Te-sheng | Ensemble music and local storytelling | CH05 CH27 CH53 |
| FILM-026 | 《歡迎來到布達佩斯大飯店》 *The Grand Budapest Hotel* | 2014 | Wes Anderson | Symmetry, aspect ratio and art direction | CH02 CH17 CH54 |
| FILM-027 | 《樂來越愛你》 *La La Land* | 2016 | Damien Chazelle | Long takes, musicals, color scripting | CH03 CH05 CH55 |
| FILM-028 | 《駭客任務》 *The Matrix* | 1999 | Lana Wachowski; Lilly Wachowski | Bullet time and action previs | CH13 CH33 CH56 |
| FILM-029 | 《楚門的世界》 *The Truman Show* | 1998 | Peter Weir | Surveillance framing and point of view | CH02 CH25 CH57 |
| FILM-030 | 《摩登時代》 *Modern Times* | 1936 | Charlie Chaplin | Visual comedy and rhythmic action | CH04 CH23 CH58 |
| FILM-031 | 《神隱少女》 *Spirited Away* | 2001 | Hayao Miyazaki | World building, color, sound and animation | CH18 CH31 CH59 |
| FILM-032 | 《黑獄亡魂》 *The Third Man* | 1949 | Carol Reed | Dutch angles, shadow and suspense | CH03 CH19 CH60 |

## 認證來源與獎項填寫規則

- 核心攝影示例：《公民凱恩》的深焦、低角度、非線性敘事，參 BFI https://www.bfi.org.uk/film/f4c92833-af39-5cd6-a41e-8df5933d0dc1/citizen-kane
- 《花樣年華》2000 年坎城最佳男演員及技術大獎，參 Cannes https://www.festival-cannes.com/en/retrospective/2000/awards/
- 《寄生上流》2020 奧斯卡最佳影片、導演、國際影片等，參 Academy https://www.oscars.org/oscars/ceremonies/2020
- 未列獎項的影片不能推定「沒得獎」，必須以影展和影藝學院原始紀錄核對並補 source URL、年份、獎項名稱與獲獎／提名的區別。

## 圖像與致敬固定圖說

中文：『本圖為原創 AI 生成的教學示意圖，參考《電影中文名》（年份）的〔鏡頭技法〕；非原電影劇照，無官方授權或合作關係。』

English: 'This original AI-generated teaching illustration draws on the [cinematic technique] discussed in *Film Title* (Year). It is not a film still and is not affiliated with or endorsed by the film's rights holders.'

不得要求精準復刻電影劇照、著名角色外貌、電影海報、特定服裝或獨特可識別的場景配置；應改以原創人物、原創場景、不同構圖呈現可教學的技法。標示『參考』不是侵權免責或授權憑證，正式使用仍需逐圖評估。
