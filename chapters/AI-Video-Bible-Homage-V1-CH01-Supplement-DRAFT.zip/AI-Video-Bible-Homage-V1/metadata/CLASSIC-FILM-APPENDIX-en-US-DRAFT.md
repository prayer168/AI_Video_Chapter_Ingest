# Classic Film Homage Appendix (Editorial Draft V1.0)

This preliminary filmography presents representative cast members, a brief synopsis, and possible chapter references. Awards are omitted unless independently verified with official sources. Entries are not publication approved.

## FILM-001 *Citizen Kane* (1941)
- Director: Orson Welles
- Selected cast: Orson Welles; Joseph Cotten
- Teaching focus: Deep focus, low angles, non-linear narration
- Proposed chapter links: CH01 CH02 CH09 CH14
- Awards: Official citation required before publication.

## FILM-002 *Rashomon* (1950)
- Director: Akira Kurosawa
- Selected cast: Toshiro Mifune; Machiko Kyo
- Teaching focus: Multiple perspectives and unreliable narration
- Proposed chapter links: CH01 CH11 CH26
- Awards: Official citation required before publication.

## FILM-003 *A City of Sadness* (1989)
- Director: Hou Hsiao-hsien
- Selected cast: Tony Leung Chiu-wai; Chen Sung-young
- Teaching focus: Long takes, offscreen space, historical context
- Proposed chapter links: CH01 CH06 CH27
- Awards: Official citation required before publication.

## FILM-004 *Yi Yi* (2000)
- Director: Edward Yang
- Selected cast: Wu Nien-jen; Elaine Jin
- Teaching focus: Urban compositions and layered perspectives
- Proposed chapter links: CH01 CH02 CH20
- Awards: Official citation required before publication.

## FILM-005 *In the Mood for Love* (2000)
- Director: Wong Kar-wai
- Selected cast: Tony Leung Chiu-wai; Maggie Cheung
- Teaching focus: Framing, repetition, color, music
- Proposed chapter links: CH01 CH02 CH15 CH22
- Awards: Official citation required before publication.

## FILM-006 *2001: A Space Odyssey* (1968)
- Director: Stanley Kubrick
- Selected cast: Keir Dullea; Gary Lockwood
- Teaching focus: Symmetry, pacing, sound-image relations
- Proposed chapter links: CH02 CH08 CH24
- Awards: Official citation required before publication.

## FILM-007 *The Godfather* (1972)
- Director: Francis Ford Coppola
- Selected cast: Marlon Brando; Al Pacino
- Teaching focus: Low-key lighting, power blocking
- Proposed chapter links: CH02 CH17 CH29
- Awards: Official citation required before publication.

## FILM-008 *Jaws* (1975)
- Director: Steven Spielberg
- Selected cast: Roy Scheider; Robert Shaw
- Teaching focus: Offscreen threat, suspense, musical motif
- Proposed chapter links: CH05 CH19 CH34
- Awards: Official citation required before publication.

## FILM-009 *Saving Private Ryan* (1998)
- Director: Steven Spielberg
- Selected cast: Tom Hanks; Matt Damon
- Teaching focus: Handheld immediacy, desaturation, sound
- Proposed chapter links: CH02 CH04 CH36
- Awards: Official citation required before publication.

## FILM-010 *Crouching Tiger, Hidden Dragon* (2000)
- Director: Ang Lee
- Selected cast: Chow Yun-fat; Michelle Yeoh
- Teaching focus: Action choreography and landscape
- Proposed chapter links: CH03 CH21 CH32
- Awards: Official citation required before publication.

## FILM-011 *A Touch of Zen* (1971)
- Director: King Hu
- Selected cast: Hsu Feng; Shih Chun
- Teaching focus: Action staging, editing and architecture
- Proposed chapter links: CH03 CH18 CH32
- Awards: Official citation required before publication.

## FILM-012 *Farewell My Concubine* (1993)
- Director: Chen Kaige
- Selected cast: Leslie Cheung; Gong Li
- Teaching focus: Historical narrative, performance and costume
- Proposed chapter links: CH04 CH21 CH37
- Awards: Official citation required before publication.

## FILM-013 *The Assassin* (2015)
- Director: Hou Hsiao-hsien
- Selected cast: Shu Qi; Chang Chen
- Teaching focus: Negative space, lighting, restrained action
- Proposed chapter links: CH03 CH06 CH38
- Awards: Official citation required before publication.

## FILM-014 *Arrival* (2016)
- Director: Denis Villeneuve
- Selected cast: Amy Adams; Jeremy Renner
- Teaching focus: Nonlinear revelation and sound design
- Proposed chapter links: CH07 CH11 CH40
- Awards: Official citation required before publication.

## FILM-015 *Blade Runner* (1982)
- Director: Ridley Scott
- Selected cast: Harrison Ford; Rutger Hauer
- Teaching focus: Atmospheric production design, lighting
- Proposed chapter links: CH03 CH17 CH42
- Awards: Official citation required before publication.

## FILM-016 *Blade Runner 2049* (2017)
- Director: Denis Villeneuve
- Selected cast: Ryan Gosling; Harrison Ford
- Teaching focus: Color architecture and visual scale
- Proposed chapter links: CH03 CH17 CH43
- Awards: Official citation required before publication.

## FILM-017 *Interstellar* (2014)
- Director: Christopher Nolan
- Selected cast: Matthew McConaughey; Anne Hathaway
- Teaching focus: Sound, time structure, visual effects
- Proposed chapter links: CH05 CH08 CH45
- Awards: Official citation required before publication.

## FILM-018 *Memento* (2000)
- Director: Christopher Nolan
- Selected cast: Guy Pearce; Carrie-Anne Moss
- Teaching focus: Reverse chronology, subjective narration
- Proposed chapter links: CH04 CH11 CH46
- Awards: Official citation required before publication.

## FILM-019 *Mad Max: Fury Road* (2015)
- Director: George Miller
- Selected cast: Tom Hardy; Charlize Theron
- Teaching focus: Action readability and centered framing
- Proposed chapter links: CH04 CH12 CH47
- Awards: Official citation required before publication.

## FILM-020 *Parasite* (2019)
- Director: Bong Joon-ho
- Selected cast: Song Kang-ho; Choi Woo-shik
- Teaching focus: Spatial hierarchy and staging
- Proposed chapter links: CH07 CH20 CH48
- Awards: Official citation required before publication.

## FILM-021 *Everything Everywhere All at Once* (2022)
- Director: Daniel Kwan; Daniel Scheinert
- Selected cast: Michelle Yeoh; Stephanie Hsu
- Teaching focus: Multiverse editing and practical ingenuity
- Proposed chapter links: CH04 CH13 CH49
- Awards: Official citation required before publication.

## FILM-022 *Seven Samurai* (1954)
- Director: Akira Kurosawa
- Selected cast: Toshiro Mifune; Takashi Shimura
- Teaching focus: Ensemble blocking and action geography
- Proposed chapter links: CH02 CH10 CH50
- Awards: Official citation required before publication.

## FILM-023 *Tokyo Story* (1953)
- Director: Yasujiro Ozu
- Selected cast: Chishu Ryu; Setsuko Hara
- Teaching focus: Low camera height and contemplative cuts
- Proposed chapter links: CH06 CH23 CH51
- Awards: Official citation required before publication.

## FILM-024 *A Brighter Summer Day* (1991)
- Director: Edward Yang
- Selected cast: Chang Chen; Lisa Yang
- Teaching focus: Long-form ensemble staging
- Proposed chapter links: CH05 CH26 CH52
- Awards: Official citation required before publication.

## FILM-025 *Cape No. 7* (2008)
- Director: Wei Te-sheng
- Selected cast: Van Fan; Tanaka Chie
- Teaching focus: Ensemble music and local storytelling
- Proposed chapter links: CH05 CH27 CH53
- Awards: Official citation required before publication.

## FILM-026 *The Grand Budapest Hotel* (2014)
- Director: Wes Anderson
- Selected cast: Ralph Fiennes; Tony Revolori
- Teaching focus: Symmetry, aspect ratio and art direction
- Proposed chapter links: CH02 CH17 CH54
- Awards: Official citation required before publication.

## FILM-027 *La La Land* (2016)
- Director: Damien Chazelle
- Selected cast: Ryan Gosling; Emma Stone
- Teaching focus: Long takes, musicals, color scripting
- Proposed chapter links: CH03 CH05 CH55
- Awards: Official citation required before publication.

## FILM-028 *The Matrix* (1999)
- Director: Lana Wachowski; Lilly Wachowski
- Selected cast: Keanu Reeves; Carrie-Anne Moss
- Teaching focus: Bullet time and action previs
- Proposed chapter links: CH13 CH33 CH56
- Awards: Official citation required before publication.

## FILM-029 *The Truman Show* (1998)
- Director: Peter Weir
- Selected cast: Jim Carrey; Laura Linney
- Teaching focus: Surveillance framing and point of view
- Proposed chapter links: CH02 CH25 CH57
- Awards: Official citation required before publication.

## FILM-030 *Modern Times* (1936)
- Director: Charlie Chaplin
- Selected cast: Charlie Chaplin; Paulette Goddard
- Teaching focus: Visual comedy and rhythmic action
- Proposed chapter links: CH04 CH23 CH58
- Awards: Official citation required before publication.

## FILM-031 *Spirited Away* (2001)
- Director: Hayao Miyazaki
- Selected cast: Rumi Hiiragi (voice); Miyu Irino (voice)
- Teaching focus: World building, color, sound and animation
- Proposed chapter links: CH18 CH31 CH59
- Awards: Official citation required before publication.

## FILM-032 *The Third Man* (1949)
- Director: Carol Reed
- Selected cast: Joseph Cotten; Orson Welles
- Teaching focus: Dutch angles, shadow and suspense
- Proposed chapter links: CH03 CH19 CH60
- Awards: Official citation required before publication.
