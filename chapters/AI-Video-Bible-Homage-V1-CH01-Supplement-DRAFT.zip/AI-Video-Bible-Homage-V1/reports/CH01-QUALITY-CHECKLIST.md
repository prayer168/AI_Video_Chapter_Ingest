# CH01 V2.0｜交付檢核清單（2026-10-18）

| 項目 | 狀態 | 證據／缺口 |
|---|---|---|
| 全書致敬清單 V1.0 | PASS（候選索引） | 32 部電影 CSV/Markdown；章節配置待對照 canonical 60 章 |
| CH01 五部電影案例繁中 | PASS（插入草稿） | CH01-HOMAGE-zh-TW-INSERT.md |
| CH01 五部電影案例英文 | PASS（插入草稿） | CH01-HOMAGE-en-US-INSERT.md |
| 雙語致敬圖說與 alt 規格 | PASS（metadata 草案） | CH01-HOMAGE-FIGURES.json |
| 電影來源逐項核查 | PARTIAL | BFI 與 Cannes 已核；其餘來源和獎項待核 |
| 原創致敬影像五張 | BLOCKED | brief 已編寫，尚未逐張生成與人工審查 |
| CH01 V2 主稿完整性 | BLOCKED | 本包是補充稿，未覆寫也未合併 canonical 主稿 |
| 中英段落 ID、術語、翻譯人工審校 | BLOCKED | 需要與完整本機 CH01 檔案合併後驗收 |
| AI 圖像 rights/technical/editorial 三核准 | BLOCKED | 均為 pending |
| 網站 /zh-tw/、/en/ 實際 build | BLOCKED | 必須由本機 Codex 執行並留證 |
| 中文 PDF 字型實際嵌入／渲染 | BLOCKED | 必須生成正式樣章後以 pdffonts 檢驗、實測手機 |
| 英文 PDF / 雙語 EPUB、DOCX | BLOCKED | 尚未由本包產生與驗證 |
| 作者正式核准 | BLOCKED | 尚未獲得 |

**結論：CH01 尚未全部完成，禁止標示 publication-ready。**
