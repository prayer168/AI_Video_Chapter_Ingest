# CH01 Supplemental Section: Homages to Classic Cinema

**Status: Insertion draft pending author and editorial approval. Suggested placement: after Section 1.5; do not overwrite the canonical chapter.**

## 1.5A Learning Audiovisual Language from Classic Films

Classic films are valuable to study not because they possess some mysterious, irreproducible “cinematic look,” but because filmmakers arrange shots, blocking, sound, and editing to guide what viewers know and feel. AI filmmakers should isolate the teachable method, then test it with original characters and situations rather than reproduce a recognizable shot.

### Case 1: *Citizen Kane* (1941) — Multiple Narrative Layers in One Frame

Directed by and starring Orson Welles, *Citizen Kane* reconstructs the life of a newspaper magnate through conflicting recollections. Deep-focus photography, low camera angles, and nonlinear narration help viewers observe foreground and background relationships while reassessing a character. Cinematographer Gregg Toland's contribution deserves explicit recognition.

**AI exercise:** In an original classroom, stage a teacher arranging equipment in the foreground, students talking in the middle ground, and a person waiting near a distant doorway. Keep several depth planes legible, and inspect positional continuity across adjacent shots.

**Caption draft:** This original AI-generated teaching illustration references the layered composition and deep-focus techniques discussed in *Citizen Kane* (1941). It is not a still from the film.

### Case 2: *Rashomon* (1950) — Perspective as Narrative Structure

Akira Kurosawa's *Rashomon* presents incompatible accounts of an event, drawing attention to the gap between witnessing and believing. The film provides a way to distinguish an occurrence from a character's perspective and the order in which information reaches the audience.

**AI exercise:** Invent a classroom incident in which an apparatus falls to the floor. Present it from a teacher's, a student's, and a distant observer's viewpoints while keeping the underlying occurrence consistent.

**Caption draft:** This original AI-generated teaching illustration references the multiple narrative perspectives explored in *Rashomon* (1950). It is not a still from the film.

### Case 3: *A City of Sadness* (1989) — History and Domestic Space

Hou Hsiao-hsien's *A City of Sadness* situates a family's daily experiences within a period of historical upheaval in Taiwan. Restrained camera placement, prolonged observation, and offscreen space invite viewers to consider the relationship between characters and their era. Its historical subject should never be reduced to a merely decorative aesthetic.

**AI exercise:** Construct an entirely original family dining room, using a static shot, doorframes, and offscreen voices to suggest that events continue beyond what the camera can see.

**Caption draft:** This original AI-generated teaching illustration references the spatial layering and restrained narrative approach discussed in *A City of Sadness* (1989). It is not a still from the film.

### Case 4: *In the Mood for Love* (2000) — Repetition, Framing, and Emotion

Wong Kar-wai's *In the Mood for Love* uses corridors, doorways, color, movement, and repeated music to build emotional rhythm. It shows that what remains unspoken can be as important as visible action.

**AI exercise:** Place fictional characters in an entirely new library corridor. Repeat a simple walk three times while varying duration, sound, and framing; compare the emotional implications.

**Caption draft:** This original AI-generated teaching illustration references the framing and rhythmic design discussed in *In the Mood for Love* (2000). It is not a still from the film.

### Case 5: *Yi Yi* (2000) — Multiple Ways of Seeing Urban Life

Edward Yang's *Yi Yi* follows a family's experiences across the city, suggesting the limits of any one individual's perspective. Windows, reflections, architecture, and everyday detail invite the viewer to consider the simultaneous presence of characters and surroundings.

**AI exercise:** In an original school hallway, compose a reflective window shot with a character inside and activity outside, maintaining credible reflection geometry and consistent positions.

**Caption draft:** This original AI-generated teaching illustration references urban spatial composition and layered viewpoints discussed in *Yi Yi* (2000). It is not a still from the film.

## Reader Exercise

Choose one film above and identify a specific, testable cinematic technique. Develop a three-shot story with entirely original characters and locations. Write each shot's narrative purpose before production, then evaluate framing, eyelines, continuity, sound, and editing. Change only one variable at a time, recording the difference.

## Sources and Outstanding Verification

- BFI, *Citizen Kane*: https://www.bfi.org.uk/film/f4c92833-af39-5cd6-a41e-8df5933d0dc1/citizen-kane
- Festival de Cannes, 2000 awards: https://www.festival-cannes.com/en/retrospective/2000/awards/
- Original/directorial sources for the other film-production claims still need editorial verification before publication.
