# AI 電影製作聖經｜第一章 Codex 交接包

## 內容

- `chapter/CH01-cinematic-language.md`：第一章可編輯 Markdown 正文
- `examples/shot-S03.json`：第一章範例鏡頭規格
- `prompts/S03-image-to-video.txt`：AI 影片生成示範提示詞
- `CODEX-INSTRUCTIONS.md`：給 Codex 的工作指令

## 使用

1. 解壓縮後將資料夾交給 Codex，或把檔案加入書籍 GitHub repo。
2. 請 Codex 先進行格式、連結、JSON 驗證，再整合到全書。
3. 不要將工具規格、學術史料或圖像引用視為已經核實；需另行核對。
4. 本檔案不含聊天 UI 互動元件及網路圖片；互動測驗已改成文字練習。

## 建議路徑

`volumes/01-film-language/CH01-cinematic-language.md`
